
This simulator shows the different phase for each process and it shows how the processes get running together.

The output shows the Process: process-number process-status... (cpu-time block-time accumulated-time accumulated-time).

In status we see that the process is blocked, completed or registered.

These models shows that each process goes to different state to be run and finish the process, the processes blocked time by time to do their  I/O or other process get a chance to have time from cpu slides.

Scheduling is a method for running threads and processes in cpu, that all of them have a chance to be run and finish after an appropriate time and also they have to use all the resources that they need during the run time. One of the scheduling is Round Rubin, it gives fixed time unit from cpu to each process and in a loops in runs all the process to finish them one by one. 
If this algorithm give small time to each process because of the switching between processes it has a lot of overhead, because of the high waiting times deadlines are rarely meet in a Round Robin systems.

